//
//  HomeTableCell1.swift
//  NewProject
//
//  Created by Apple on 15/08/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class HomeTableCell1: UITableViewCell
{

    @IBOutlet weak var entertain_btn: UIButton!
    @IBOutlet weak var paid_btn: UIButton!
    @IBOutlet weak var feature_btn: UIButton!
    @IBOutlet weak var detailContainer_view: UIView!
    
    @IBOutlet weak var Distancelbl: UILabel!
    @IBOutlet weak var comment: UILabel!
    @IBOutlet weak var Likelbl: UILabel!
    @IBOutlet weak var viewlbl: UILabel!
    @IBOutlet weak var topimg: UIImageView!
    @IBOutlet weak var eventtype: UILabel!
    @IBOutlet weak var tittle1lbl: UILabel!
    
    @IBOutlet weak var tittle2: UILabel!
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setUI()
    }
    
    func setUI()
    {
        detailContainer_view.layer.borderColor = UIColor.lightGray.cgColor
        detailContainer_view.layer.borderWidth = 1
        detailContainer_view.layer.cornerRadius = 8
        feature_btn.layer.cornerRadius = 8
        eventtype.layer.cornerRadius = 8
    }
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
