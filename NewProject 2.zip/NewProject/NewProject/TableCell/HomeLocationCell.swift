//
//  HomeLocationCell.swift
//  NewProject
//
//  Created by Apple on 15/08/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class HomeLocationCell: UITableViewCell
{

    
    @IBOutlet weak var loction1: UILabel!
    @IBOutlet weak var location3: UILabel!
    @IBOutlet weak var location2: UILabel!
    @IBOutlet weak var container_view: UIView!
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setUI()
    }
    func setUI()
    {
        container_view.layer.cornerRadius = 8
    }
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

    }

}
