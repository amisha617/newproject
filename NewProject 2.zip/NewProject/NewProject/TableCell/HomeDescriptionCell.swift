//
//  HomeDescriptionCell.swift
//  NewProject
//
//  Created by Apple on 15/08/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class HomeDescriptionCell: UITableViewCell
{

    @IBOutlet weak var container_view: UIView!
    
    @IBOutlet weak var descrptionlbl: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setUI()
    }
    func setUI()
    {
        container_view.layer.cornerRadius = 8
    }
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

    }

}
