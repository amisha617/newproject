//
//  HomeEventCell.swift
//  NewProject
//
//  Created by Apple on 15/08/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class HomeEventCell: UITableViewCell
{

    @IBOutlet weak var container_view: UIView!
    @IBOutlet weak var eventCollection_view: UICollectionView!
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setUI()
        // Initialization code
    }
    func setUI()
    {
        eventCollection_view.delegate = self
        eventCollection_view.dataSource = self
        container_view.layer.cornerRadius = 8
    }
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
extension HomeEventCell:UICollectionViewDelegate,UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ViewEventCell", for: indexPath) as! ViewEventCell
        cell.setUI()
        return cell
    }
}
