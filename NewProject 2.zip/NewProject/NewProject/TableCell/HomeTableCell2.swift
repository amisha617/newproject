//
//  HomeTableCell2.swift
//  NewProject
//
//  Created by Apple on 15/08/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class HomeTableCell2: UITableViewCell {

     @IBOutlet weak var container_view: UIView!
      @IBOutlet weak var timelbl: UILabel!
     @IBOutlet weak var langulbl: UILabel!
    
    @IBOutlet weak var genderlbl: UILabel!
    @IBOutlet weak var datelbl: UILabel!
    @IBOutlet weak var yeralbl: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        setUI()
    }
    func setUI()
    {
        container_view.layer.cornerRadius = 8
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
