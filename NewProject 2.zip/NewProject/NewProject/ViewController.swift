//
//  ViewController.swift
//  NewProject
//
//  Created by Apple on 15/08/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import Alamofire
import KRProgressHUD
import SDWebImage
class ViewController: UIViewController
{

    @IBOutlet weak var table_view: UITableView!
    @IBOutlet var header_view: UIView!
    @IBOutlet weak var addtecket_btn: UIButton!
    @IBOutlet weak var promote_btn: UIButton!
    var dataarry = [data_detail]()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setUI()
        hitServicegetAPI()
        
    }
    
    func setUI()
    {
        table_view.delegate = self
        table_view.dataSource = self
        addtecket_btn.layer.cornerRadius = 10
        promote_btn.layer.cornerRadius = 10
    }
    
}
extension ViewController:UITableViewDelegate,UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if section == 0
        {
            return dataarry.count
        }
        else
        {
            
            return 7
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.section == 0
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableCell1", for: indexPath) as! HomeTableCell1
            
//           let categoryImage = dataarry[indexPath.row].image
//           cell.topimg.sd_setImage(with: URL(string: categoryImage), completed: nil)
//            cell.viewlbl.text = dataarry[indexPath.row].ev_views
//            cell.Likelbl.text = dataarry[indexPath.row].ev_like
//
//            cell.comment.text = dataarry[indexPath.row].commentCount
//            cell.Distancelbl.text = dataarry[indexPath.row].distance
//            cell.tittle1lbl.text = dataarry[indexPath.row].ev_title
//            cell.eventtype.text = dataarry[indexPath.row].event_type_name
//            cell.tittle2.text = dataarry[indexPath.row].ev_title_ar
            return cell
        }
        else
        {
            if indexPath.row == 0
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableCell2", for: indexPath) as! HomeTableCell2
                
                
                return cell
            }
            else if indexPath.row == 1
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "HomeLocationCell", for: indexPath) as! HomeLocationCell
                
//                cell.loction1.text = dataarry[indexPath.row].ev_country
//                cell.location2.text = dataarry[indexPath.row].ev_city
//                cell.location3.text = dataarry[indexPath.row].ev_address

                return cell
            }
            else if indexPath.row == 2
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "HomeDescriptionCell", for: indexPath) as! HomeDescriptionCell
              //  cell.descrptionlbl.text = dataarry[indexPath.row].ev_description
                return cell
            }
            else if indexPath.row == 3
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "HomeEventCell", for: indexPath) as! HomeEventCell
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "HomeVeiwEventsCell", for: indexPath) as! HomeVeiwEventsCell
                return cell
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        if section == 1
        {
            return header_view
        }
        else
        {
            return UIView()
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if section == 1
        {
           return 40
        }
        else
        {
           return 0
        }
    }
}

extension ViewController {
    func hitServicegetAPI()
       {
          
           KRProgressHUD.set(activityIndicatorViewColors: [#colorLiteral(red: 0, green: 0.2156862745, blue: 0.3725490196, alpha: 1)])
           KRProgressHUD.show()
          let parameters = [
            "user_id" : 00,
           "event_id" : 12,
           "longitude" : 78.1245,
           "latitude" : 28.1245
            ] as [String:Any]
           print(parameters)
        
        
           ServiceManager.instance.request(method: .post, URLString:"", parameters: parameters, encoding: URLEncoding.default, headers: nil)
           { (success, dictionary, error) in
               KRProgressHUD.dismiss()
               if (success)!
               {
                   let statuscode = dictionary?["error_code"] as? NSNumber
                   if statuscode == 100
                   {
                       if (dictionary?["data"]) != nil
                       {
                        if let resultdict = dictionary?["data"] as? [String:Any]
                        {      var data_obj = data_detail()
                            if let ev_title = resultdict["ev_title"] as? String
                            {
                               data_obj.ev_title =  ev_title
                               
                            }
                            if let ev_title_ar = resultdict["ev_title_ar"] as? String
                            {
                               data_obj.ev_title_ar =  ev_title_ar
                               
                            }
                           if let ev_title_ar = resultdict["ev_start_date"] as? String
                            {
                               data_obj.ev_title_ar =  ev_title_ar
                               
                            }
                            if let ev_title_ar = resultdict["ev_end_date"] as? String
                            {
                               data_obj.ev_title_ar =  ev_title_ar
                               
                            }
                            
                            
                            if let ev_title_ar = resultdict["ev_start_time"] as? String
                            {
                                data_obj.ev_title_ar =  ev_title_ar
                                
                            }
                            
                            if let ev_title_ar = resultdict["ev_end_time"] as? String
                            {
                                data_obj.ev_title_ar =  ev_title_ar
                                
                            }
                            
                            
                            if let ev_image = resultdict["ev_image"] as?[[String : Any ]]
                            {
                                if let  image  = ev_image[0]["image"] as? String {
                                      data_obj.image =  image
                                }
                                  
                                
                            }
                            if let ev_country = resultdict["ev_country"] as? String
                            {
                                data_obj.ev_country =  ev_country
                                
                            }
                            if let ev_city = resultdict["ev_city"] as? String
                            {
                                data_obj.ev_city =  ev_city
                                
                            }
                           
                            if let  ev_address = resultdict["ev_address"] as? String
                            {
                                data_obj.ev_address =  ev_address
                                
                            }
                            if let  ev_lat = resultdict["ev_lat"] as? String
                            {
                                data_obj.ev_lat =  ev_lat
                                
                            }
                            if let  ev_long = resultdict["ev_long"] as? String
                            {
                                data_obj.ev_long =  ev_long
                                
                            }
                            
                            if let  ev_gender = resultdict["ev_gender"] as? String
                            {
                                data_obj.ev_gender =  ev_gender
                                
                            }
                            if let  ev_language = resultdict["ev_language"] as? String
                            {
                                data_obj.ev_language =  ev_language
                                
                            }
                            
                            if let  ev_description = resultdict["ev_description"] as? String
                            {
                                data_obj.ev_description =  ev_description
                                
                            }
                            
                            
                            
                            
                            if let  ev_views = resultdict["ev_views"] as? String
                            {
                                data_obj.ev_views =  ev_views
                                
                            }
                            
                            if let  ev_like = resultdict["ev_like"] as? String
                            {
                                data_obj.ev_like = ev_like
                                
                            }
                            if let  distance = resultdict["distance"] as? String
                            {
                                data_obj.distance =  distance
                                
                            }
                            if let  ev_event_type_name = resultdict["ev_event_type_name"] as? String
                            {
                                data_obj.event_type_name = ev_event_type_name
                                
                            }
                            
                            if let  commentCount = resultdict["commentCount"] as? String
                            {
                                data_obj.commentCount = commentCount
                                
                            }
                            
                            if let itemdict = resultdict["event_organizer"] as? [[String:Any]]
                            {
                                var organizer_obj = organizer()
                                for data in itemdict
                                {
                                    if let  o_name = data["o_name"] as? String
                                    {
                                        organizer_obj.organizer_name = o_name
                                        
                                    }
                                    if let  o_logo = data["o_logo"] as? String
                                    {
                                        organizer_obj.organiger_logo = o_logo
                                        
                                    }
                                    
                                    data_obj.event_organizer.append(organizer_obj)
                                }
                                
                                if let itemdict = resultdict["event_performer"] as? [[String:Any]]
                                {
                                    var performer_obj = performer()
                                    for data in itemdict
                                    {
                                        if let  o_name = data["o_name"] as? String
                                        {
                                            performer_obj.performer_name = o_name
                                            
                                        }
                                        if let  o_logo = data["o_logo"] as? String
                                        {
                                            performer_obj.performer_logo = o_logo
                                            
                                        }
                                        
                                        data_obj.event_performer.append(performer_obj)
                                    }
                                    
                             if let itemdict = resultdict["event_sponser"] as? [[String:Any]]
                             {
                                 var sponser_obj = sponser()
                                 for data in itemdict
                                 {
                                    if let  o_name = data["o_name"] as? String
                                    {
                                        sponser_obj.sponser_name = o_name
                                        
                                    }
                                    if let  o_logo = data["o_logo"] as? String
                                    {
                                        sponser_obj.sponser_name = o_logo
                                        
                                    }
                                    
                
                                     data_obj.event_sponser.append(sponser_obj)
                                 }
                                 
                                self.dataarry.append(data_obj)
                                
                            }
                            }
                                
                            }
                            
                            
                            
                            self.table_view.reloadData()
                            
                        }
                    }
                   }
                   else {
                    print("No data")
                }
            }
        }
    }
}

struct data_detail
{
    var tittle = ""
    var ev_title = ""
    var ev_title_ar = ""
    var image = ""
    var ev_country = ""
    var ev_city  = ""
    var  ev_address  = ""
    var ev_lat  = ""
    var ev_long = ""
    var ev_gender = ""
    var ev_language = ""
    var ev_description = ""
    var  event_type_name =  ""
    var ev_views = ""
    var ev_like = ""
    var distance = ""
    var commentCount = ""
    var event_organizer = [organizer]()
    var event_sponser = [sponser]()
    var event_performer = [performer]()
}

struct organizer {
    var organizer_name = ""
    var organiger_logo = ""
}

struct sponser {
    var sponser_name = ""
    var sponser_logo = ""
}

struct performer {
    var performer_name = ""
    var performer_logo = ""
}
