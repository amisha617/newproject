//
//  File.swift
//  Wadooni
//
//  Created by appl on 25/11/19.
//  Copyright © 2019 com.ripenapps.wadooni. All rights reserved.
//

import Foundation

struct Constant
{
    static var string = Constant()
    let appname = "BelleXD"
}
