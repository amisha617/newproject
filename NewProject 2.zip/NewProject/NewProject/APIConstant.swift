//
//  APIConstant.swift
//  Wadooni
//
//  Created by appl on 23/11/19.
//  Copyright © 2019 com.ripenapps.wadooni. All rights reserved.
//

import Foundation
import UIKit

let BASEURL = "http://saudicalendar.com/api/user/getEventDetail"
let kAlertNoNetworkMessage = "A network connection is required. Please verify your network settings & try again."

