//
//  ViewEventCell.swift
//  NewProject
//
//  Created by Apple on 15/08/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit

class ViewEventCell: UICollectionViewCell
{
    @IBOutlet weak var container_view: UIView!
    @IBOutlet weak var image_view: UIImageView!
    
    func setUI()
    {
        container_view.layer.borderColor = UIColor.lightGray.cgColor
        container_view.layer.borderWidth = 1
        container_view.layer.cornerRadius = 5
        image_view.layer.cornerRadius = image_view.frame.size.height/2
    }
}
